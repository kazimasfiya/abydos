import Digital from "../InnerPages/Digital";

export default Digital