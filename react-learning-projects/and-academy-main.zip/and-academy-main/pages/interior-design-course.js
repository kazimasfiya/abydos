import Interior from "../InnerPages/Interior";

export default Interior