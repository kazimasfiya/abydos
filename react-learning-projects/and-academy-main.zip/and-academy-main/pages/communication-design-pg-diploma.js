import Communication from "../InnerPages/Communication";

export default Communication