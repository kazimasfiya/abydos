import Graphic from "../InnerPages/Graphic";

export default Graphic