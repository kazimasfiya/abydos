import HomeIndex from "../components/Home"

export default HomeIndex