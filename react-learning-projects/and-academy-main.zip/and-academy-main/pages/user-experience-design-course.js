import User from "../InnerPages/User";

export default User